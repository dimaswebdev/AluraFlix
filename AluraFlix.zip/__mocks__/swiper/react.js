export const Swiper = ({ children }) => (
  <div className="swiper">{children}</div>
);
export const SwiperSlide = ({ children }) => (
  <div className="swiper-slide">{children}</div>
);
