import React, { useState } from "react";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "../../firebase";
import "./LoginModal.css";

const LoginModal = ({ onClose }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [tooltip, setTooltip] = useState(""); // Estado para gerenciar tooltips

  const handleLogin = async () => {
    try {
      await signInWithEmailAndPassword(auth, email, password);
      alert("Login realizado com sucesso!");
      onClose(); // Fecha o modal após login
    } catch (error) {
      alert("Erro ao fazer login: " + error.message);
    }
  };

  const handleFocus = (inputType) => {
    if (inputType === "email") {
      setTooltip("Digite o email aluraflix@one.com");
    } else if (inputType === "password") {
      setTooltip("Digite a senha DimasAluraOne2024!");
    }
  };

  const handleBlur = () => {
    setTooltip(""); // Remove o tooltip ao perder o foco
  };

  return (
    <div className="popup-overlay">
      <div className="popup-content">
        <button className="close-button" onClick={onClose}>
          &times;
        </button>
        <h2>Login</h2>
        {tooltip && <div className="tooltip">{tooltip}</div>} {/* Tooltip */}
        <form>
          <div className="input-container">
            <input
              type="email"
              placeholder="E-mail"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onFocus={() => handleFocus("email")}
              onBlur={handleBlur}
            />
          </div>
          <div className="input-container">
            <input
              type={showPassword ? "text" : "password"}
              placeholder="Senha"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onFocus={() => handleFocus("password")}
              onBlur={handleBlur}
            />
            <button
              type="button"
              className="toggle-password"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? "Ocultar" : "Mostrar"}
            </button>
          </div>
          <div className="popup-buttons">
            <button type="button" onClick={handleLogin}>
              Entrar
            </button>
            <button type="button" onClick={onClose}>
              Fechar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LoginModal;
