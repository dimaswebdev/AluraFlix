import React from "react";

function Contact() {
  return (
    <div>
      <h1>Contact Us</h1>
      <p>This is the contact page.</p>
    </div>
  );
}

export default Contact;
